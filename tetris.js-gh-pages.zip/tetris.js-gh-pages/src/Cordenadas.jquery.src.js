var pieza=0; //pieza
var pos=[  //Valores referencia de coordenadas relativas
        [0,0],
        [0,1],
        [-1,0],
        [1,0],
        [-1,-1],
        [0,-1],
        [1,-1],
        [0,-2]
        ];

           //Obtiene unas coordenadas fila,columna y las rota 90 grados
           function rotarCasilla(celda){
               var pos2=[celda [ 0 ] , celda [ 1 ] ];
               for (var n=0;n < rotacion ;n++){
                   var fila=pos2 [ 1 ];
                   var columna=-pos2 [ 0 ] ;
                   pos2 [ 0 ] = fila;
                   pos2 [ 1 ] = columna;
               }
               return pos2;
}