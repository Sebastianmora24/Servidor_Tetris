
function colisionaPieza(){

           for (var v=1;v < 5;v++){
               var des=piezas[pieza][v];
               var pos2=rotarCasilla(pos[des]);
               if (cuadroNoDisponible(pos2 [ 0 ] +filaInicial, pos2 [ 1 ]+columnaInicial)){
                   return true;
               }
           }
           return false;
           }
           //Mueve la pieza lateralmente
           function moverPieza(des){
               columnaInicial=columnaInicial+des;
               if (colisionaPieza()){
                   columnaInicial=columnaInicial-des;
               }
           }

           //Rota la pieza seg�n el n�mero de rotaciones posibles tenga la pieza activa. (posici�n 0 de la pieza)
           function rotarPieza(){
                       rotacion=rotacion+1;
                       if (rotacion==piezas[pieza] [ 0 ] ){
                   rotacion=0;
               }
               if (colisionaPieza()){
                   rotacion=rotacion-1;
                           if (rotacion==-1){
                       rotacion=piezas[pieza] [ 0 ] -1;
                   }
               }
           }